package Assignment2;
import java.util.Scanner;

public class BookStoreApp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BookStore bs = new BookStore();
		bs.init();
		Scanner sc = new Scanner(System.in);
		int x;
		System.out.println("Enter your choice: ");
		do{
		System.out.println("Enter '1' to display the Books ");
		System.out.println("Enter'2' to order new Books ");
		System.out.println("Enter '3' to sell Books ");
		System.out.println("Enter '0' to exit the system ");
		x = sc.nextInt();
		String str;
		
		switch(x){
		
			case 1:
				bs.display();
				break;
			case 2:
				do{
					System.out.println("Enter the ISBN and no of copies ");
					String bookTitle = sc.next();
					int noOfCopies =sc.nextInt();
					bs.order(bookTitle,noOfCopies);
					System.out.println("Do you want to order another book?(y/n)");
					str = sc.next();
				}while(str.equals("y")||str.equals("Y"));
				break;
			case 3:
				do{
				System.out.println("Enter the book title and no of copies ");
				String isbn = sc.next();
				int noOfCopy =sc.nextInt();
				bs.sell(isbn,noOfCopy);
				System.out.println("Do you want to sell another book?(y/n");
				str = sc.next();
				}while(str.equals("y")||str.equals("Y"));
				break;
			case 0:
				System.exit(0);				
		
		}
		}while(x==1||x==2||x==3);
	}

}
