package Assignment2;

import java.util.Scanner;

public class ApplicationClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x;
		Student student = null;
		do{
		System.out.println("Enter 1 to create the Student object");
		System.out.println("Enter 2 to display Student");
		x = sc.nextInt();
		
			switch(x){
			case 1:
				System.out.println("Enter the details of the user");
				System.out.println("Enter 1 for Student id ");
				System.out.println("Enter 2 for Student name and Id");
				System.out.println("Enter 3 for Student name id and grade");
				int y = sc.nextInt();
				
				if(y==1){
					System.out.println("Enter student's id");
					String id = sc.next();
					student = new Student(id);
				}
				else if(y==2){
					System.out.println("Enter student id and student name");
					String id = sc.next();
					String name = sc.next();
					student = new Student(id,name);
				}
				else if(y==3){
					System.out.println("Enter student id , student name and grade");
					String id = sc.next();
					String name = sc.next();
					int grade = sc.nextInt();
					student = new Student(id,name,grade);
				}
				else
					System.out.println("Invalid input");
			
			case 2:
				if(student==null){
					System.out.println("Student object is not created");
				}
				else{
					System.out.println("Do you want to enter your current year?");
					String str =sc.next();
					if(str.equals("Y")||str.equals("y")){
						System.out.println("Enter your current year");
						int year = sc.nextInt();
						student.display(year);
					}
					else if(str.equals("N")||str.equals("n"))
						student.display();
					
				}
			}	
		}while(x==1||x==2);
	}

}
