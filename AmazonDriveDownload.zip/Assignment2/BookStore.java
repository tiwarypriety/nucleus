package Assignment2;

public class BookStore {
Book[] books = new Book[2];
Book ob = new Book();
void init(){

    books[0]= new Book("Wings Of Fire","A.P.J Abdul Kalam","ISBN101",4);
	books[1] = new Book("C","Y. Kanetkar","ISBN102",2);
	//Include 8 more book details
}

void sell(String bookTitle, int noOfCopies){
	for(int i=0;i<books.length;i++){
		if(bookTitle.equals(books[i].bookTitle)){
			ob.numOfCopies = ob.numOfCopies-noOfCopies;
			return;
		}
	}
	System.out.println("Sorry! Book Not found!");
}
void order(String isbn,int noOfCopies){
	for(int i=0;i<books.length;i++){
		if(isbn.equals(books[i].ISBN)){
			ob.numOfCopies = ob.numOfCopies+noOfCopies;
			return;
		}
		else
			System.out.println("Books not matched!");
			
	}
	
	
}
void display(){
	for(int i=0;i<books.length;i++){
		System.out.println(books[i].bookTitle+" - "+books[i].author+" - "+books[i].ISBN+" - "+books[i].numOfCopies);
	}
}
}
