package Assignment2;

import java.util.Scanner;

public class Bank
{
		
		public static void main(String[] args)
		{
			SavingsAccount s=new SavingsAccount();
			Scanner sc=new Scanner(System.in);
			System.out.println("Create an account..");
			System.out.println("enter your name:");
			System.out.println(sc.next());
			System.out.println("Which account would you like to open?");
			System.out.println("1.Savings account");
			System.out.println("2.Current account");
			sc.nextInt();
			s.genAccNo();
			System.out.println("select an option:");
			System.out.println("1:Deposit Money");
			System.out.println("2:Withdraw Money");
			System.out.println("3:Balance Enquiry");
			int i=sc.nextInt();
			switch(i)
			{
			case 0: break;
			case 1:
			
					System.out.println("enter the amount to deposit");
					double d=sc.nextDouble();
					s.deposit(d);
					break;
			case 2:
					System.out.println("enter the amount to deposit");
					double wd=sc.nextDouble();
					s.withDrawMoney(wd);
					break;
			case 3:
					System.out.println(s.getBalance());
					break;
			
			default:
				System.out.println("enter a valid option");
			}
			System.out.println("Do you want to know account balance?Yes or No");
			String str=sc.next();
			if(str.equalsIgnoreCase("yes"))
						System.out.println(s.getBalance());
			sc.close();
				
		}
	
}
