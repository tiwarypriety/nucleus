package Assignment2;

import java.util.Scanner;

public class ApplicationCar {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.out.println("Enter '1' to create Vehicle Object");
		System.out.println("Enter '2' to create Car object");
		System.out.println("Enter '3' to create Convertible object");
		System.out.println("Enter '4' to create Sport Car");
		Vehicle vc = null;
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		switch(x){
		case 1:
			vc = new Vehicle(4,5,101,"Maruti");
			vc.display();			
			break;
		case 2:
			vc = new Car(4);
			vc.display();
			break;
		case 3:
			vc = new Convertible(true);
			vc.display();
			break;
		case 4:
			vc = new SportCar();
			vc.display();
		}
	}

}
