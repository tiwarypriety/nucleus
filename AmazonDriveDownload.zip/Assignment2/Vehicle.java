package Assignment2; 

public class Vehicle {
private int noOfWheel;
private int noOfPassenger;
private int model;
private String make;
public int getNoOfWheel() {
	return noOfWheel;
}
public void setNoOfWheel(int noOfWheel) {
	this.noOfWheel = noOfWheel;
}
public int getNoOfPassenger() {
	return noOfPassenger;
}
public void setNoOfPassenger(int noOfPassenger) {
	this.noOfPassenger = noOfPassenger;
}
public int getModel() {
	return model;
}
public void setModel(int model) {
	this.model = model;
}
public String getMake() {
	return make;
}
public void setMake(String make) {
	this.make = make;
}

Vehicle(){}
Vehicle(int noOfWheel, int noOfPassenger,int model, String make){
	this.noOfPassenger=noOfPassenger;
	this.noOfWheel = noOfWheel;
	this.model = model;
	this.make = make;
}

void display(){
	System.out.println("Make: "+make+", Model: "+model+", Number of Wheel: "+noOfWheel+", Number of passenger: "+noOfPassenger);
}
}
