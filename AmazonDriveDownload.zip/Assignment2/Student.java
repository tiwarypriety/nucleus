package Assignment2;

public class Student {
	private String name;
	private String id;
	private int grade;
	Student(String id){
		this.id =id;
	}
	Student(String name,String id){
		this(id);
		this.name = name;
	}
	Student(String name, String id, int grade){
		this(name,id);
		this.grade = grade;
	}
	void display(){
		System.out.println("Name: "+name+", ID: "+id+", Grade: "+grade);
	}
	void display(int year){
		System.out.println("Name: "+name+", ID: "+id+", Grade: "+grade+", Year: "+year);
	}
}
