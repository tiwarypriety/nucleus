package Assignment2;

public class Book {
String bookTitle;
String author;
String ISBN;
int numOfCopies;
Book(){}
	Book(String bookTitle,String author,String ISBN,int numOfCopies){
		this.bookTitle=bookTitle;
		this.author = author;
		this.ISBN = ISBN;
		this.numOfCopies = numOfCopies;
	}
	void display(){
		System.out.println(bookTitle+" - "+author+" - "+ISBN+" - "+numOfCopies);
	}
}
