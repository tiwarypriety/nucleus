package Assignment2;

public class Convertible extends Car {
	
private boolean isHoodOpen;
Convertible(boolean isHoodopen){
	this.isHoodOpen=isHoodopen;
}
private String make = getMake();
private int model = getModel();
private int noOfDoor = getNoOfDoor();
void display(){
	System.out.println("Make: "+make+", Model: "+model+", No of Door: "+noOfDoor+", IsHoodOpen: "+isHoodOpen);
}
}
