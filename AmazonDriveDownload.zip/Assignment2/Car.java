package Assignment2;

public class Car extends Vehicle {

private int noOfDoor;
private String make = getMake();
private int model = getModel();
public String getMake() {
	return make;
}

public void setMake(String make) {
	this.make = make;
}

public int getModel() {
	return model;
}

public void setModel(int model) {
	this.model = model;
}

public int getNoOfDoor() {
	return noOfDoor;
}

public void setNoOfDoor(int noOfDoor) {
	this.noOfDoor = noOfDoor;
}
Car(){
	super();
}
Car(int noOfDoor){
	this.noOfDoor = noOfDoor;
}
void display(){
	System.out.println("Make: "+make+", Model: "+model+", No of Door: "+noOfDoor);
}
}
