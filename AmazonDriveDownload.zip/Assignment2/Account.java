package Assignment2;
import java.util.Random;
import java.util.Scanner;

public class Account
{
String mName;
long accNo;
double accBal;
Account()
{
	
}
Account(long accNo)
{
	this.accNo=accNo;
}
public void deposit(double d)
{
	accBal+=d;
}
public  long genAccNo()
{
	Random r=new Random();
	long a=10000+ r.nextInt(89999);
	System.out.println("your account no is"+a);
	return a;
}
}

class SavingsAccount extends Account
{
	double interest=5;
	static double maxWithdrawLimit=100000;
	static double minBal=1000;
	SavingsAccount()
	{
		
	}
	public double getBalance()
	{
		accBal+=interest;
		return accBal;
	}
	public void withDrawMoney(double wd)
	{
		if(wd<maxWithdrawLimit&&(accBal-wd)>minBal)
			accBal-=wd;
		else
			System.out.println("Sorry!!!..transaction is crossing the limit...");
	}
}

class CurrentAccount extends Account
{
	String tradeLicenseNo;
	public double getBalance()
	{
		return accBal;
	}
	public void withDrawMoney(double wd)
	{
		if(wd<accBal)
			accBal-=wd;
		else
			System.out.println("your account does no have sufficient balance");
	}
	
}

