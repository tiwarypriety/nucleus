package Assignment2;

public class SportCar extends Car {
	
	private int noOfDoor=2;
}
