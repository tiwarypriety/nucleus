package Assignment3;

public class Vehicle {
	private int vehicleno;
	private int model;
	private String make;
	private String manufacturer;
	private String color;
	
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getVehicleno() {
		return vehicleno;
	}
	public void setVehicleno(int vehicleno) {
		this.vehicleno = vehicleno;
	}
	public int getModel() {
		return model;
	}
	public void setModel(int model) {
		this.model = model;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	
	@Override
	public String toString() {
		return "Vehicle [vehicleno=" + vehicleno + ", model=" + model
				+ ", make=" + make + ", manufacturer=" + manufacturer
				+ ", color=" + color + "]";
	}
	Vehicle(int vno,int model,String make, String manufacturer,String color){
		this.vehicleno = vno;
		this.color=color;
		this.make = make;
		this.model = model;
		this.manufacturer = manufacturer;
	}
	
	
}
