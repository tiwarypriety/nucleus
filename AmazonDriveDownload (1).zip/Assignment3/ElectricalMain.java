package Assignment3;

public class ElectricalMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		ElectricalProduct ep =new ElectricalProduct(101, "Fan", 1001, 1200.0f, 250, 15);
		ep.change(18, 1100.0f);
		System.out.println(ep);
	}

}
