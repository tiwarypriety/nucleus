package Assignment3;

public class Manager extends Employee1 {
	
	String department;
	Manager(String name, float sal,String dept) {
		super(name, sal);
		this.department = dept;
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Manager [department=" + department + ", name=" + name
				+ ", salary=" + salary + "]";
	}
	
}
