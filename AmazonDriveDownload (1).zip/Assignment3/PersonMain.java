package Assignment3;

public class PersonMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student2 st = new Student2("Ujjwal", 1996 , "Information Technology");
		Instructor ins = new Instructor("Mohan", 1992, 1600);
		System.out.println(st);
		System.out.println(ins);
	}

}
