package Assignment3;

public class ExecutiveMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Executive ex = new Executive("Ramesh",40000.5f,"Developer");
		System.out.println(ex);
	}

}
