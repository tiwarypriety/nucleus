package Assignment3;

public class Student2 extends Person{


String major;
Student2(String name, int year,String major) {
	super(name, year);
	// TODO Auto-generated constructor stub
	this.major = major;
}
@Override
public String toString() {
	return "Student2 [major=" + major + ", name=" + name + ", yearofBirth="
			+ yearofBirth + "]";
}

}
