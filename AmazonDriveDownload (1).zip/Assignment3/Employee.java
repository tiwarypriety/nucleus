package Assignment3;

public class Employee {
	private String empId, name,designastion,phoneNumber;
	private int projectId;
	
	Employee(String empId,String name, String designation, String no,int pid){
		this.empId=empId;
		this.name = name;
		this.designastion =designation;
		this.phoneNumber = no;
		this.projectId=pid;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignastion() {
		return designastion;
	}

	public void setDesignastion(String designastion) {
		this.designastion = designastion;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	
	
	
	
}
