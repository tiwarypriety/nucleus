package Assignment3;

public class Product {

	private int productId;
	private String name;
	private int categoryId;
	private float unitPrice;
	
	Product(int pid,String name, int catId, float price){
		this.productId = pid;
		this.name=name;
		this.categoryId=catId;
		this.unitPrice = price;
	}
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public float getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(float unitPrice) {
		this.unitPrice = unitPrice;
	} 
	
}
