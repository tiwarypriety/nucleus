package Assignment3;

public class CurrentBalance extends Account{
double minBalance=5000;
boolean chequefacility = true;
public void display(){
	double accountBalance =super.getAccountBalance();
	if(accountBalance<minBalance){
		accountBalance-=(accountBalance*1.5)/100;	
	}
	System.out.println("Your account balance is"+accountBalance);
	                                                 
}

}
