package Assignment3;

public class Periodical extends Book {
	

	private int period;
	private int bookId = super.getBookId();
	private float price = super.getPrice();
	private String author = super.getAuthor();
	private String title = super.getTitle();
	
	Periodical(int bookId, String title, String author, float price, int period) {
		super(bookId, title, author, price);
		// TODO Auto-generated constructor stub
		this.period=period;
	}
	
	void change(float price, int period){
		this.price = price;
		this.period=period;
	}

	@Override
	public String toString() {
		return "Periodical [period=" + period + ", bookId=" + bookId
				+ ", price=" + price + ", author=" + author + ", title="
				+ title + "]";
	}
	
	
	
}
