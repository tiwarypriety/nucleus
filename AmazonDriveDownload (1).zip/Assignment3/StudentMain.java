package Assignment3;

public class StudentMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hosteller host = new Hosteller("NSBT115", "Ujjwal", "JAVA101","MALE" , "8109763771", "Vaishnav Hostel", 10);
		host.change(25, "9631613666");
		System.out.println(host);
	}

}
