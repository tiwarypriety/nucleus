package Assignment3;

public class Person {
String name;
int yearofBirth;
Person(String name,int year){
	this.name = name;
	this.yearofBirth=year;
}
}
