package Assignment3;

public class Hosteller extends Student {
	
	

	private String hostelName;
	private int roomNo;
	
	private String studentId=super.getStudentId();
	private String name = super.getName();
	private String courseId = super.getCourseId();
	private String sex = super.getSex();
	private String phoneNo = super.getPhoneNo();
	
	Hosteller(String sid, String sname, String cId, String s, String pno,String hname, int roomno) {
		super(sid, sname, cId, s, pno);
		// TODO Auto-generated constructor stub
		this.hostelName =hname;
		this.roomNo = roomno;
		
	}
	
	void change(int roomNo, String phoneNo){
		this.roomNo=roomNo;
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "Hosteller [hostelname=" + hostelName + ", roomNo=" + roomNo
				+ ", studentId=" + studentId + ", name=" + name + ", courseId="
				+ courseId + ", sex=" + sex + ", phoneNo=" + phoneNo + "]";
	}
	
	
	
}
