package Assignment3;

public class SavingAccount extends Account{
int interest = 5;
//private double accountBalance = super.getAccountBalance();


public void display(){
	double accountBalance = super.getAccountBalance();
	accountBalance = accountBalance+(accountBalance*5)/100;
	System.out.println(accountBalance);
}
}
