package Assignment3;

public class BookMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Book book;
		book = new Periodical(101,"Wings Of Fire","A.P.J Abdul Kalam",250.0f,5);
		System.out.println(book);
	}

}
