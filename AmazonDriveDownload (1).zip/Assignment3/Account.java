package Assignment3;

import java.util.Random;

public class Account {
	private String customerName;
	private String accountNo;
	private String type_of_account;
	private double accountBalance;
	
	
	
	public String getCustomerName() {
		return customerName;
	}



	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}



	public String getAccountNo() {
		return accountNo;
	}



	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}



	public String getType_of_account() {
		return type_of_account;
	}



	public void setType_of_account(String type_of_account) {
		this.type_of_account = type_of_account;
	}



	public double getAccountBalance() {
		return accountBalance;
	}



	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}



	void deposit(double amount){
		accountBalance+=amount;
		System.out.println("Your amount has been deposited");
	}
	double withdraw(double amount){
		if(accountBalance>amount){
		accountBalance = accountBalance-amount;
		}
		else{
			System.out.println("Sorry!! Your account has less balance");
		}
		return accountBalance;
	}
	
	void random1(){
		Random rand = new Random();
		 accountNo ="" + rand.nextInt(10) + rand.nextInt(10)+ rand.nextInt(10)+
		rand.nextInt(10)+ rand.nextInt(10);
	}
}
