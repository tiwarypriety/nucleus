package Assignment3;

public class Truck extends Vehicle{
	
	
	private String loadingCapacity = "100 tonns";
	String color = super.getColor();
	int vehicleno = super.getVehicleno();
	int model = super.getModel();
	String make = super.getMake();
	String manufacturer = super.getManufacturer(); 
	
	Truck(int vno, int model, String make, String manufacturer, String color) {
		super(vno, model, make, manufacturer, color);

	}

	
	public void change(String color, String loadingCapacity){
		this.color = color;
		this.loadingCapacity = loadingCapacity;
	}


	@Override
	public String toString() {
		return "Truck [loadingCapacity=" + loadingCapacity + ", color=" + color
				+ ", vehicleno=" + vehicleno + ", model=" + model + ", make="
				+ make + ", manufacturer=" + manufacturer + "]";
	}


	
	
	
	
	
}
