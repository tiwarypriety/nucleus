package Assignment3;

public class PracticeHead extends Employee {

	private String practiceName;
	private int noOfCustomer;
	
	String empId = super.getEmpId();
	String name = super.getName();
	String designation = super.getDesignastion();
	String phoneNumber = super.getPhoneNumber();
	int ProductId = super.getProjectId();
	
	PracticeHead(String empId, String name, String designation, String no,
			int pid,String practiceName,int noOfCustomer) {
		super(empId, name, designation, no, pid);
		// TODO Auto-generated constructor stub
		this.practiceName = practiceName;
		this.noOfCustomer = noOfCustomer;
	}
	void change(int noOfCustomer, String phoneNo){
		this.noOfCustomer = noOfCustomer;
		this.phoneNumber = phoneNo;
	}
	@Override
	public String toString() {
		return "PracticeHead [practiceName=" + practiceName + ", noOfCustomer="
				+ noOfCustomer + ", empId=" + empId + ", name=" + name
				+ ", designation=" + designation + ", phoneNumber="
				+ phoneNumber + ", ProductId=" + ProductId + "]";
	}
	
	

}
