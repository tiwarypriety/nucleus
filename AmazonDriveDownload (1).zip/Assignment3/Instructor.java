package Assignment3;

public class Instructor extends Person {
	int salary;
	Instructor(String name, int year, int sal) {
		super(name, year);
		// TODO Auto-generated constructor stub
		this.salary =sal;
	}
	@Override
	public String toString() {
		return "Instructor [salary=" + salary + ", name=" + name
				+ ", yearofBirth=" + yearofBirth + "]";
	}

}
