package Assignment3;

public class VehicleMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Truck t1 = new Truck(5678,121,"Moto","Motorola","Red");
		t1.change("black", "50tonns");
		System.out.println(t1);
	}

}
