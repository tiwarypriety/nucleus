package Assignment3;

public class Employee1 {
String name;
float salary;
Employee1(String name,float sal){
	this.name = name;
	this.salary =sal;
}
}
