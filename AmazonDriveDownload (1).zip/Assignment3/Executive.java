package Assignment3;

public class Executive extends Manager{

	Executive(String name, float sal, String dept) {
		super(name, sal, dept);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Executive [department=" + department + ", name=" + name
				+ ", salary=" + salary + "]";
	}
	
}
