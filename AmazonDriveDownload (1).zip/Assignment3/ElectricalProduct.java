package Assignment3;

public class ElectricalProduct extends Product {
	

	private int voltagerange;
	private int wattage;
	
	private int productid = super.getProductId();
	private String name = super.getName();
	private int categoryId = super.getCategoryId();
	private float unitPrice = super.getUnitPrice();
	
	ElectricalProduct(int pid, String name, int catId, float price,int voltage,int watt) {
		super(pid, name, catId, price);
		this.voltagerange = voltage;
		this.wattage =watt;
		// TODO Auto-generated constructor stub
	}

	void change(int watt, float price){
		this.wattage = watt;
		this.unitPrice = price;
	}

	@Override
	public String toString() {
		return "ElectricalProduct [voltagerange=" + voltagerange + ", wattage="
				+ wattage + ", productid=" + productid + ", name=" + name
				+ ", categoryId=" + categoryId + ", unitPrice=" + unitPrice
				+ "]";
	}
	
	
}
