package Assignment3;

public class EmployeeMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PracticeHead ph = new PracticeHead("NSBT115", "Ujjwal", "Trainee", "8109763771", 101, "Amit", 60);
		ph.change(100, "96316131666");
		System.out.println(ph);
	}

}
