package Assignment3;

import java.util.Scanner;


public class Bank {

	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Welcome to open your account");
		System.out.println("Enter your name");
		String name = sc.next();
		System.out.println("Enter the initial amount you want to deposit in your account ");
		double initialbalance = sc.nextDouble();
		
		System.out.println("What type of account do you want to open?\n 1. Saving Account \n 2. Current Account");
		int x = sc.nextInt();
		int y;
		do{
		switch(x){
		case 1:
			SavingAccount sa =new SavingAccount();
			sa.setAccountBalance(initialbalance);
			sa.setCustomerName(name);
			sa.setType_of_account("Saving Account");
			sa.random1();
			System.out.println("Congrats! Your account has been created ");
			do{
				System.out.println("Enter '1' to deposit money");
				System.out.println("Enter '2' to withdraw money");
				System.out.println("Enter '3' to display current balance");
				y = sc.nextInt();
				switch(y){
					case 1:
						System.out.println("Enter the amount you want to deposit");
						double amount = sc.nextDouble();
						sa.deposit(amount);
						break;
					case 2:
						System.out.println("Enter the amount you want to withdraw");
						amount = sc.nextDouble();
						sa.withdraw(amount);
						break;
					case 3:
						sa.display();
						break;
						
				}
				}while(y==1||y==2||y==3);
			System.exit(0);
			break;
		case 2:
			CurrentBalance ca = new CurrentBalance();
			ca.setAccountBalance(initialbalance);
			ca.setCustomerName(name);
			ca.setType_of_account("Current Account");
			ca.random1();
			System.out.println("Congrats! Your account has been created ");
			do{
			System.out.println("Enter '1' to deposit money");
			System.out.println("Enter '2' to withdraw money");
			System.out.println("Enter '3' to display current balance");
			y = sc.nextInt();
			switch(y){
				case 1:
					System.out.println("Enter the amount you want to deposit");
					double amount = sc.nextDouble();
					ca.deposit(amount);
					break;
				case 2:
					System.out.println("Enter the amount you want to withdraw");
					amount = sc.nextDouble();
					ca.withdraw(amount);
					break;
				case 3:
					ca.display();
					break;
					
			}
			}while(y==1||y==2||y==3);
			System.exit(0);
			break;
		case 3:
			System.exit(0);
		default:
			System.out.println("Wrong Choice!");
				
		}
		}while(x==1||x==2);		
		
		
	
		
		
	}

}
